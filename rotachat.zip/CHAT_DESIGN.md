# Design Brainstorm: Sistema de Chat do RotaChat

## Contexto
O Sistema de Chat é a interface principal onde usuários interagem. Deve ser intuitiva, moderna e inspirada no UOL Chat clássico, mas com design cyberpunk neon do RotaChat.

---

## Design Selecionado: Cyberpunk Chat Interface

**Design Movement:** UOL Chat modernizado com cyberpunk neon + glassmorphism

**Core Principles:**
- Layout de duas colunas: lista de salas/usuários (esquerda), chat (direita)
- Avatares com moldura animada estilo Whiteout Survival
- Mensagens com timestamps e status
- Controles intuitivos (emoji, enviar, etc)
- Glassmorphic cards com neon borders

**Color Philosophy:**
- Fundo: Escuro com gradiente sutil
- Cards: Glassmorphic com borda neon
- Mensagens próprias: Azul/roxo
- Mensagens alheias: Cinza/transparente
- Avatares: Moldura com glow neon
- Status online: Verde neon

**Layout Paradigm:**
- Sidebar esquerda: 25-30% da largura (desktop)
- Chat area: 70-75% da largura (desktop)
- Mobile: Stack vertical com toggle entre sidebar/chat
- Header do chat com nome da sala/usuário
- Área de mensagens scrollável
- Input box fixo no bottom

**Signature Elements:**
1. **Avatar com Moldura Animada:** Glow pulsante, ondas, partículas
2. **Status Indicator:** Bolinha verde/vermelha com glow
3. **Message Bubbles:** Glassmorphic com borda neon
4. **Neon Borders:** Linhas divisórias com gradientes

**Interaction Philosophy:**
- Hover em usuário: destaca com glow
- Click em usuário: abre chat
- Hover em mensagem: mostra ações (react, delete, etc)
- Typing indicator: animação de 3 pontos
- Enviar: animação de envio

**Animation:**
- Avatar glow: pulse 2s infinite
- Ondas no avatar: wave animation 3s infinite
- Partículas: float animation
- Mensagens: fade-in slide-up 300ms
- Status: blink sutil

**Typography System:**
- Nickname: Space Grotesk 600, 14px
- Mensagem: Inter 400, 14px
- Timestamp: Inter 300, 12px
- Status: Inter 500, 12px

**Visual Assets Needed:**
1. Avatares de exemplo (5-6 usuários)
2. Molduras animadas para avatares
3. Ícones de status (online, offline, typing)

---

## Especificações Técnicas

### Layout
- Sidebar width: 280px (desktop), 100% (mobile)
- Chat area: flex-1
- Message input: 60px height
- Avatar size: 40px (list), 48px (chat header)

### Cores
- Mensagem própria: oklch(0.65 0.25 260) (azul)
- Mensagem alheia: oklch(0.15 0.02 260) (escuro)
- Status online: oklch(0.65 0.25 140) (verde)
- Status offline: oklch(0.40 0.05 0) (cinza)
- Borda neon: oklch(0.65 0.25 260)

### Efeitos
- Glassmorphism: backdrop-filter blur(12px)
- Avatar glow: box-shadow com cores neon
- Border glow: box-shadow com cores neon
- Transições: 300ms ease-in-out

---

## Componentes a Implementar
1. **ChatContainer** - Layout principal com sidebar + chat
2. **UserList** - Lista de usuários/salas com avatares
3. **ChatWindow** - Área de mensagens
4. **ChatHeader** - Info do chat (nome, status, ações)
5. **MessageList** - Lista de mensagens com scroll
6. **MessageBubble** - Componente individual de mensagem
7. **ChatInput** - Input box com emoji, send button
8. **AvatarWithFrame** - Avatar com moldura animada
9. **StatusIndicator** - Indicador de status online/offline
10. **TypingIndicator** - Animação "digitando..."

