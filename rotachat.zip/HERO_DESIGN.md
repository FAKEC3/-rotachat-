# Design Brainstorm: Hero / Banner Principal do RotaChat

## Contexto
O Hero é a primeira impressão visual após o Header. Deve ser impactante, transmitir energia e convidar o usuário a entrar no chat. Segue a filosofia cyberpunk neon do RotaChat.

---

## Design Selecionado: Cyberpunk Neon Hero

**Design Movement:** Cyberpunk + Synthwave com elementos de jogos online

**Core Principles:**
- Contraste visual alto com gradientes neon dinâmicos
- Profundidade através de camadas e efeitos de parallax
- Tipografia ousada e chamativa
- Dois CTAs principais bem definidos

**Color Philosophy:**
- Fundo: Gradiente escuro com toque de azul/roxo profundo
- Overlay: Gradiente de azul → roxo → rosa (semi-transparente)
- Texto: Branco puro para máximo contraste
- Botões: Laranja vibrante (CTA primária), Verde/Azul (CTA secundária)
- Filosofia: Transmitir urgência, energia e diversão

**Layout Paradigm:**
- Full-width hero section com altura 100vh ou 90vh
- Imagem/background dinâmica como base
- Conteúdo centralizado com grid assimétrico
- Título grande e impactante
- Subtítulo descritivo
- Dois botões lado a lado (desktop), empilhados (mobile)
- Efeito de parallax sutil no background

**Signature Elements:**
1. **Gradiente Neon Overlay:** Camada semi-transparente com gradiente azul → roxo → rosa
2. **Partículas/Efeitos:** Pequenas luzes flutuando (CSS animations)
3. **Glow Effects:** Halos luminosos nos botões e texto

**Interaction Philosophy:**
- Hover nos botões: intensifica o glow, scale(1.05)
- Background: movimento sutil (parallax ao scroll)
- Transições: 300ms ease-in-out

**Animation:**
- Partículas flutuantes: animação contínua vertical
- Título: fade-in com slide-up ao carregar
- Botões: pulse sutil ou glow intensificado ao hover
- Transições: 300ms cubic-bezier(0.4, 0, 0.2, 1)

**Typography System:**
- Título: Space Grotesk 700, 48-64px (desktop), 32-40px (mobile)
- Subtítulo: Inter 400, 18-20px (desktop), 14-16px (mobile)
- Botões: Space Grotesk 600, 14-16px

**Visual Assets Needed:**
1. Background hero image: Cidade futurista com luzes neon, céu com gradiente azul/roxo/rosa
2. Overlay gradiente: Azul → Roxo → Rosa (semi-transparente)
3. Partículas/efeitos: Gerados via CSS ou SVG

---

## Especificações Técnicas

### Dimensões
- Height: 100vh (full viewport) ou 90vh
- Padding: 40px (mobile), 60px (desktop)
- Max-width: 1280px (conteúdo)

### Cores
- Background gradient: oklch(0.08 0.01 260) → oklch(0.12 0.02 260)
- Overlay gradient: rgba(0, 153, 255, 0.1) → rgba(157, 78, 221, 0.1) → rgba(255, 0, 110, 0.1)
- Texto: oklch(0.95 0.01 0)
- CTA Primária: oklch(0.65 0.30 30) (Laranja)
- CTA Secundária: oklch(0.65 0.25 260) (Azul)

### Efeitos
- Glassmorphism: backdrop-filter blur(8px)
- Glow: box-shadow com cores neon
- Parallax: transform translateY() baseado em scroll
- Partículas: @keyframes com animation infinite

---

## Componentes a Implementar
1. **Hero Container** - Full-width, background image + overlay
2. **Hero Content** - Título, subtítulo, botões
3. **CTA Buttons** - Entrar no Chat (primária), Explorar Salas (secundária)
4. **Floating Particles** - Efeito decorativo com CSS animations
5. **Responsive Design** - Mobile, tablet, desktop

