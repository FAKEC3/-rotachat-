import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ChatPage from "./pages/ChatPage";
import RandomChatPage from "./pages/RandomChatPage";
import CitiesPage from "./pages/CitiesPage";


function Router() {
  return (
    <Switch>
      <Route path={"/ "} component={Home} />
      <Route path={"/chat"} component={ChatPage} />
      <Route path={"/aleatorio"} component={RandomChatPage} />
      <Route path={"/cidades"} component={CitiesPage} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: RotaChat Design System
// - Theme: Dark cyberpunk neon aesthetic
// - Colors: Neon blue (#0099FF), purple, pink, orange on dark background
// - Typography: Space Grotesk (bold headers), Inter (body)
// - Effects: Glassmorphism, glow effects, smooth animations

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
