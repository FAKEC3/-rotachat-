import Header from "@/components/Header";
import Cities from "@/components/Cities";

/**
 * Cities Page
 * 
 * Route: /cidades
 * Displays the cities discovery interface
 */

export default function CitiesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Cities />
    </div>
  );
}
