import Header from "@/components/Header";
import Chat from "@/components/Chat";

/**
 * Chat Page
 * 
 * Route: /chat
 * Displays the main chat interface with UOL-style layout
 */

export default function ChatPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Chat />
    </div>
  );
}
