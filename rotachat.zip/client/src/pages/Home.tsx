import Header from "@/components/Header";
import Hero from "@/components/Hero";

/**
 * RotaChat Home Page
 * 
 * Design Philosophy: Cyberpunk Neon
 * - Dark background with neon accents
 * - Glassmorphic cards and elements
 * - Smooth animations and transitions
 * - Fully responsive layout
 */

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      {/* Hero Section */}
      <Hero />
      
      {/* Placeholder for future sections */}
      <main className="bg-background">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-lg text-foreground/70">
              Próximas seções em desenvolvimento...
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
