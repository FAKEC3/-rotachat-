import Header from "@/components/Header";
import RandomChat from "@/components/RandomChat";

/**
 * Random Chat Page
 * 
 * Route: /aleatorio
 * Displays the random chat interface (Omegle-style)
 */

export default function RandomChatPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <RandomChat />
    </div>
  );
}
