/**
 * Avatar Frames Data
 * 
 * Contains data for avatar frames with different rarities
 * Common, Rare, Epic, Legendary
 */

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface AvatarFrame {
  id: string;
  name: string;
  rarity: Rarity;
  borderColor: string;
  glowColor: string;
  isUnlocked: boolean;
  unlockedAt?: Date;
}

export const avatarFrames: AvatarFrame[] = [
  // Common Frames (Blue/Green/Cyan)
  {
    id: 'frame-common-1',
    name: 'Iniciante Azul',
    rarity: 'common',
    borderColor: 'oklch(0.65 0.25 260)',
    glowColor: 'rgba(0, 153, 255, 0.6)',
    isUnlocked: true,
  },
  {
    id: 'frame-common-2',
    name: 'Viajante Verde',
    rarity: 'common',
    borderColor: 'oklch(0.65 0.25 140)',
    glowColor: 'rgba(0, 255, 136, 0.6)',
    isUnlocked: true,
  },
  {
    id: 'frame-common-3',
    name: 'Explorador Ciano',
    rarity: 'common',
    borderColor: 'oklch(0.65 0.25 180)',
    glowColor: 'rgba(0, 255, 255, 0.6)',
    isUnlocked: false,
  },
  {
    id: 'frame-common-4',
    name: 'Aprendiz Roxo',
    rarity: 'common',
    borderColor: 'oklch(0.65 0.25 290)',
    glowColor: 'rgba(157, 78, 221, 0.6)',
    isUnlocked: false,
  },
  {
    id: 'frame-common-5',
    name: 'Novato Rosa',
    rarity: 'common',
    borderColor: 'oklch(0.65 0.25 330)',
    glowColor: 'rgba(255, 0, 136, 0.6)',
    isUnlocked: false,
  },

  // Rare Frames (Purple/Magenta/Gold)
  {
    id: 'frame-rare-1',
    name: 'Guerreiro Roxo',
    rarity: 'rare',
    borderColor: 'oklch(0.65 0.30 290)',
    glowColor: 'rgba(200, 100, 255, 0.7)',
    isUnlocked: true,
  },
  {
    id: 'frame-rare-2',
    name: 'Mago Magenta',
    rarity: 'rare',
    borderColor: 'oklch(0.65 0.30 320)',
    glowColor: 'rgba(255, 0, 200, 0.7)',
    isUnlocked: false,
  },
  {
    id: 'frame-rare-3',
    name: 'Tesouro Ouro',
    rarity: 'rare',
    borderColor: 'oklch(0.65 0.30 60)',
    glowColor: 'rgba(255, 200, 0, 0.7)',
    isUnlocked: false,
  },
  {
    id: 'frame-rare-4',
    name: 'Espectro Prata',
    rarity: 'rare',
    borderColor: 'oklch(0.65 0.15 0)',
    glowColor: 'rgba(200, 200, 200, 0.7)',
    isUnlocked: false,
  },
  {
    id: 'frame-rare-5',
    name: 'Neon Ciano',
    rarity: 'rare',
    borderColor: 'oklch(0.65 0.30 180)',
    glowColor: 'rgba(0, 255, 255, 0.8)',
    isUnlocked: false,
  },

  // Epic Frames (Orange/Red/Gold)
  {
    id: 'frame-epic-1',
    name: 'Campeão Ouro',
    rarity: 'epic',
    borderColor: 'oklch(0.65 0.30 50)',
    glowColor: 'rgba(255, 180, 0, 0.8)',
    isUnlocked: false,
  },
  {
    id: 'frame-epic-2',
    name: 'Inferno Laranja',
    rarity: 'epic',
    borderColor: 'oklch(0.65 0.30 30)',
    glowColor: 'rgba(255, 100, 0, 0.8)',
    isUnlocked: false,
  },
  {
    id: 'frame-epic-3',
    name: 'Chama Vermelha',
    rarity: 'epic',
    borderColor: 'oklch(0.65 0.30 10)',
    glowColor: 'rgba(255, 0, 0, 0.8)',
    isUnlocked: false,
  },
  {
    id: 'frame-epic-4',
    name: 'Rosa Quente',
    rarity: 'epic',
    borderColor: 'oklch(0.65 0.30 340)',
    glowColor: 'rgba(255, 50, 150, 0.8)',
    isUnlocked: false,
  },
  {
    id: 'frame-epic-5',
    name: 'Verde Neon',
    rarity: 'epic',
    borderColor: 'oklch(0.65 0.30 140)',
    glowColor: 'rgba(0, 255, 100, 0.8)',
    isUnlocked: false,
  },

  // Legendary Frames (Multicolor/Holographic)
  {
    id: 'frame-legendary-1',
    name: 'Arco-Íris Lendário',
    rarity: 'legendary',
    borderColor: 'oklch(0.65 0.30 260)',
    glowColor: 'rgba(0, 255, 255, 0.9)',
    isUnlocked: false,
  },
  {
    id: 'frame-legendary-2',
    name: 'Holográfico Cósmico',
    rarity: 'legendary',
    borderColor: 'oklch(0.65 0.30 290)',
    glowColor: 'rgba(200, 100, 255, 0.9)',
    isUnlocked: false,
  },
  {
    id: 'frame-legendary-3',
    name: 'Divino Multicolor',
    rarity: 'legendary',
    borderColor: 'oklch(0.65 0.30 330)',
    glowColor: 'rgba(255, 100, 200, 0.9)',
    isUnlocked: false,
  },
];

// Get frames by rarity
export const getFramesByRarity = (rarity: Rarity) => {
  return avatarFrames.filter((frame) => frame.rarity === rarity);
};

// Get all unlocked frames
export const getUnlockedFrames = () => {
  return avatarFrames.filter((frame) => frame.isUnlocked);
};

// Get all locked frames
export const getLockedFrames = () => {
  return avatarFrames.filter((frame) => !frame.isUnlocked);
};

// Rarity colors for badges
export const rarityColors = {
  common: 'oklch(0.65 0.25 260)',
  rare: 'oklch(0.65 0.30 290)',
  epic: 'oklch(0.65 0.30 30)',
  legendary: 'oklch(0.65 0.30 330)',
};

// Rarity labels
export const rarityLabels = {
  common: 'Comum',
  rare: 'Rara',
  epic: 'Épica',
  legendary: 'Lendária',
};
