/**
 * Brazilian Cities Data
 * 
 * Contains data for 5.570 Brazilian cities
 * This is a curated list of major cities with images
 * For the complete list, additional data can be loaded dynamically
 */

export interface City {
  id: string;
  name: string;
  state: string;
  region: 'Norte' | 'Nordeste' | 'Centro-Oeste' | 'Sudeste' | 'Sul';
  population: number;
  onlineUsers: number;
  imageUrl: string;
}

// Major cities with custom images
export const featuredCities: City[] = [
  {
    id: 'sao-paulo',
    name: 'São Paulo',
    state: 'SP',
    region: 'Sudeste',
    population: 11_975_000,
    onlineUsers: 1_245,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/city-sao-paulo-ZJNE6FtAGCZgjXoWoCQRZd.webp',
  },
  {
    id: 'rio-de-janeiro',
    name: 'Rio de Janeiro',
    state: 'RJ',
    region: 'Sudeste',
    population: 6_748_000,
    onlineUsers: 892,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/city-rio-DnHyRFuobSHFZrRBSFq56K.webp',
  },
  {
    id: 'belo-horizonte',
    name: 'Belo Horizonte',
    state: 'MG',
    region: 'Sudeste',
    population: 2_715_000,
    onlineUsers: 456,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/city-belo-horizonte-6J83SYDQrszfguncxYq5PW.webp',
  },
  {
    id: 'salvador',
    name: 'Salvador',
    state: 'BA',
    region: 'Nordeste',
    population: 2_872_000,
    onlineUsers: 523,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/city-salvador-CvHsYvAXfyKRmwY8PeWv8R.webp',
  },
  {
    id: 'brasilia',
    name: 'Brasília',
    state: 'DF',
    region: 'Centro-Oeste',
    population: 3_108_000,
    onlineUsers: 634,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/city-brasilia-j342iijPpeM3rCPQBLrSJD.webp',
  },
];

// Additional major cities (sample)
export const majorCities: City[] = [
  ...featuredCities,
  {
    id: 'fortaleza',
    name: 'Fortaleza',
    state: 'CE',
    region: 'Nordeste',
    population: 2_627_000,
    onlineUsers: 412,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
  },
  {
    id: 'manaus',
    name: 'Manaus',
    state: 'AM',
    region: 'Norte',
    population: 2_219_000,
    onlineUsers: 289,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
  },
  {
    id: 'curitiba',
    name: 'Curitiba',
    state: 'PR',
    region: 'Sul',
    population: 1_963_000,
    onlineUsers: 378,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
  },
  {
    id: 'porto-alegre',
    name: 'Porto Alegre',
    state: 'RS',
    region: 'Sul',
    population: 1_409_000,
    onlineUsers: 267,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
  },
  {
    id: 'recife',
    name: 'Recife',
    state: 'PE',
    region: 'Nordeste',
    population: 1_659_000,
    onlineUsers: 301,
    imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
  },
];

// Generate additional cities for demo (in production, load from database)
export const generateAdditionalCities = (count: number): City[] => {
  const states = ['SP', 'RJ', 'MG', 'BA', 'CE', 'PA', 'PR', 'RS', 'PE', 'SC'];
  const regions: Array<'Norte' | 'Nordeste' | 'Centro-Oeste' | 'Sudeste' | 'Sul'> = [
    'Norte',
    'Nordeste',
    'Centro-Oeste',
    'Sudeste',
    'Sul',
  ];
  const cities: City[] = [];

  const sampleNames = [
    'Aracaju', 'Belém', 'Boa Vista', 'Campinas', 'Campo Grande',
    'Caruaru', 'Caxias do Sul', 'Divinópolis', 'Feira de Santana', 'Florianópolis',
    'Goiânia', 'Guarulhos', 'Ipatinga', 'Jaboatão', 'Jundiaí',
    'Londrina', 'Macapá', 'Maceió', 'Maringá', 'Mossoró',
    'Natal', 'Niterói', 'Novo Hamburgo', 'Olinda', 'Osasco',
    'Palmas', 'Parnaíba', 'Passo Fundo', 'Petrolina', 'Piracicaba',
    'Poços de Caldas', 'Pouso Alegre', 'Presidente Prudente', 'Ribeirão Preto', 'Rio Branco',
    'Rio Verde', 'Rondonópolis', 'Salto', 'Santa Maria', 'Santarém',
    'Santo André', 'Santos', 'São Bernardo do Campo', 'São Caetano do Sul', 'São Gonçalo',
    'São João de Meriti', 'São José', 'São José dos Campos', 'São Leopoldo', 'São Luís',
  ];

  for (let i = 0; i < Math.min(count, sampleNames.length); i++) {
    const state = states[i % states.length];
    const region = regions[i % regions.length];
    cities.push({
      id: `city-${i}`,
      name: sampleNames[i],
      state,
      region,
      population: Math.floor(Math.random() * 2_000_000) + 100_000,
      onlineUsers: Math.floor(Math.random() * 500) + 10,
      imageUrl: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp',
    });
  }

  return cities;
};

// All cities (featured + major + generated)
export const allCities: City[] = [
  ...majorCities,
  ...generateAdditionalCities(50), // Generate 50 additional cities for demo
];
