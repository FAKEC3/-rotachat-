import { useState } from 'react';
import { ChevronRight, LogOut, Flag } from 'lucide-react';
import AvatarWithFrame from './AvatarWithFrame';

interface Message {
  id: string;
  text: string;
  timestamp: string;
  isOwn: boolean;
}

/**
 * RandomChat Component
 * 
 * Design Philosophy: Omegle modernizado com Cyberpunk Neon
 * - Interface centrada com dois avatares lado a lado (VS)
 * - Chat area no centro
 * - Botões de ação bem definidos
 * - Animações dinâmicas
 * - Totalmente responsivo
 */

export default function RandomChat() {
  const [currentUser, setCurrentUser] = useState({
    nickname: 'Você',
    avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-1-7brhdWPrAqbGEgBpLCFGvh.webp',
    isOnline: true,
  });

  const [randomUser, setRandomUser] = useState({
    nickname: 'Juh Prati',
    avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-2-YU9bMDyqFhzg3PSwTWTEbM.webp',
    isOnline: true,
  });

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Oi! Como você está?',
      timestamp: '14:32',
      isOwn: false,
    },
    {
      id: '2',
      text: 'Tudo bem! E você?',
      timestamp: '14:33',
      isOwn: true,
    },
    {
      id: '3',
      text: 'Adorei conhecer você! 😊',
      timestamp: '14:34',
      isOwn: false,
    },
  ]);

  const [inputValue, setInputValue] = useState('');
  const [isTransitioning, setIsTransitioning] = useState(false);

  const avatarOptions = [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-1-7brhdWPrAqbGEgBpLCFGvh.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-2-YU9bMDyqFhzg3PSwTWTEbM.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-3-VAMTnvtuNfbHKtEWKJtd45.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-4-Z4xa5GtHZfA4JcQ2GVYRsK.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-5-7burmF2QisyK5p5wbxdtAZ.webp',
  ];

  const nicknames = ['Juh Prati', 'Anitas', 'Chat', 'Conige', 'Nexus', 'Lara', 'Bruno', 'Marina'];

  const handleNextUser = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      const randomAvatar = avatarOptions[Math.floor(Math.random() * avatarOptions.length)];
      const randomNickname = nicknames[Math.floor(Math.random() * nicknames.length)];
      setRandomUser({
        nickname: randomNickname,
        avatar: randomAvatar,
        isOnline: true,
      });
      setMessages([]);
      setIsTransitioning(false);
    }, 600);
  };

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      const newMessage: Message = {
        id: String(messages.length + 1),
        text: inputValue,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        isOwn: true,
      };
      setMessages([...messages, newMessage]);
      setInputValue('');
    }
  };

  return (
    <section className="w-full min-h-screen bg-background flex flex-col items-center justify-center p-4 md:p-6 pt-24 md:pt-28">
      <div className="w-full max-w-4xl">
        
        {/* Avatar Pair with VS Divider */}
        <div className="flex items-center justify-center gap-4 md:gap-8 mb-8 md:mb-12">
          {/* Left Avatar */}
          <div className={`flex flex-col items-center gap-2 transition-opacity duration-300 ${isTransitioning ? 'opacity-50' : 'opacity-100'}`}>
            <AvatarWithFrame
              src={currentUser.avatar}
              alt={currentUser.nickname}
              nickname={currentUser.nickname}
              isOnline={currentUser.isOnline}
              size="lg"
            />
            <div className="text-center">
              <p className="font-bold text-foreground">{currentUser.nickname}</p>
              <p className="text-xs text-foreground/60">🟢 Online</p>
            </div>
          </div>

          {/* VS Divider */}
          <div className="flex flex-col items-center gap-2">
            <div
              className="w-12 h-12 md:w-16 md:h-16 rounded-full glass border-2 border-secondary flex items-center justify-center font-bold text-lg md:text-xl text-secondary animate-pulse"
              style={{
                boxShadow: '0 0 20px rgba(157, 78, 221, 0.6), 0 0 40px rgba(157, 78, 221, 0.3)',
              }}
            >
              VS
            </div>
            {/* Connection Line */}
            <div className="h-8 w-0.5 bg-gradient-to-b from-primary to-secondary" />
          </div>

          {/* Right Avatar */}
          <div className={`flex flex-col items-center gap-2 transition-opacity duration-300 ${isTransitioning ? 'opacity-50' : 'opacity-100'}`}>
            <AvatarWithFrame
              src={randomUser.avatar}
              alt={randomUser.nickname}
              nickname={randomUser.nickname}
              isOnline={randomUser.isOnline}
              size="lg"
            />
            <div className="text-center">
              <p className="font-bold text-foreground">{randomUser.nickname}</p>
              <p className="text-xs text-foreground/60">🟢 Online</p>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="glass rounded-lg p-4 md:p-6 border border-border mb-6 max-h-96 overflow-y-auto space-y-4">
          {messages.length === 0 ? (
            <div className="h-64 md:h-80 flex items-center justify-center text-center">
              <div>
                <p className="text-lg font-bold text-foreground/80 mb-2">Comece uma conversa!</p>
                <p className="text-sm text-foreground/60">Diga algo para quebrar o gelo 😊</p>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg ${
                    message.isOwn
                      ? 'bg-primary/30 border border-primary/50 text-foreground'
                      : 'bg-card border border-border text-foreground'
                  }`}
                >
                  <p className="text-sm md:text-base">{message.text}</p>
                  <p className="text-xs text-foreground/50 mt-1">{message.timestamp}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Chat Input */}
        <div className="glass rounded-lg p-3 md:p-4 border border-border mb-6 flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Digite uma mensagem..."
            className="flex-1 bg-transparent text-foreground placeholder-foreground/40 outline-none text-sm md:text-base"
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-2 bg-primary/20 hover:bg-primary/30 text-primary rounded-lg transition-all duration-300 font-medium text-sm"
          >
            Enviar
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center items-center">
          
          {/* Next Button */}
          <button
            onClick={handleNextUser}
            disabled={isTransitioning}
            className="group relative px-6 md:px-8 py-3 md:py-4 rounded-lg font-bold text-sm md:text-base transition-all duration-300 flex items-center gap-2 bg-primary/20 border-2 border-primary hover:bg-primary/30 hover:shadow-lg hover:shadow-primary/50 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed text-foreground"
          >
            <span>Próximo</span>
            <ChevronRight className="w-5 h-5 md:w-6 md:h-6 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Disconnect Button */}
          <button
            className="group relative px-6 md:px-8 py-3 md:py-4 rounded-lg font-bold text-sm md:text-base transition-all duration-300 flex items-center gap-2 bg-red-900/20 border-2 border-red-600 hover:bg-red-900/30 hover:shadow-lg hover:shadow-red-600/50 hover:scale-105 text-red-400"
          >
            <LogOut className="w-5 h-5 md:w-6 md:h-6" />
            <span>Desconectar</span>
          </button>

          {/* Report Button */}
          <button
            className="group relative px-6 md:px-8 py-3 md:py-4 rounded-lg font-bold text-sm md:text-base transition-all duration-300 flex items-center gap-2 bg-orange-900/20 border-2 border-orange-600 hover:bg-orange-900/30 hover:shadow-lg hover:shadow-orange-600/50 hover:scale-105 text-orange-400"
          >
            <Flag className="w-5 h-5 md:w-6 md:h-6" />
            <span>Reportar</span>
          </button>
        </div>

        {/* Info Text */}
        <div className="mt-8 md:mt-12 text-center">
          <p className="text-sm text-foreground/60">
            Você está em uma conversa anônima. Seja respeitoso! 💬
          </p>
        </div>
      </div>
    </section>
  );
}
