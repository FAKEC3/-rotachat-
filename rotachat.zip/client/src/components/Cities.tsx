import { useState, useMemo } from 'react';
import { Search, MapPin } from 'lucide-react';
import CityCard from './CityCard';
import { allCities, City } from '@/data/cities';

type Region = 'Todos' | 'Norte' | 'Nordeste' | 'Centro-Oeste' | 'Sudeste' | 'Sul';

/**
 * Cities Component
 * 
 * Design Philosophy: Cyberpunk Neon City Discovery
 * - Search bar with autocomplete
 * - Region filters
 * - Grid of city cards
 * - Lazy loading for performance
 * - Responsive layout
 */

export default function Cities() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<Region>('Todos');
  const [displayCount, setDisplayCount] = useState(12);

  const regions: Region[] = ['Todos', 'Norte', 'Nordeste', 'Centro-Oeste', 'Sudeste', 'Sul'];

  // Filter cities based on search and region
  const filteredCities = useMemo(() => {
    return allCities.filter((city) => {
      const matchesSearch =
        city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        city.state.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesRegion = selectedRegion === 'Todos' || city.region === selectedRegion;

      return matchesSearch && matchesRegion;
    });
  }, [searchQuery, selectedRegion]);

  // Display cities with lazy loading
  const displayedCities = filteredCities.slice(0, displayCount);

  const handleLoadMore = () => {
    setDisplayCount((prev) => prev + 12);
  };

  const handleCityClick = (city: City) => {
    // Navigate to city chat room
    window.location.href = `https://www.rotachat.online/cidades/${city.id}`;
  };

  return (
    <section className="w-full min-h-screen bg-background p-4 md:p-6 pt-24 md:pt-28">
      <div className="container mx-auto">
        
        {/* Header */}
        <div className="mb-8 md:mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">
            Salas por Cidade
          </h1>
          <p className="text-foreground/60">
            Encontre salas de chat de todas as cidades brasileiras
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-primary" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setDisplayCount(12); // Reset display count on new search
              }}
              placeholder="Buscar cidade ou estado..."
              className="w-full pl-12 pr-4 py-3 md:py-4 bg-card border-2 border-border rounded-lg text-foreground placeholder-foreground/40 focus:outline-none focus:border-primary transition-colors duration-300"
            />
          </div>
        </div>

        {/* Region Filter */}
        <div className="mb-8 overflow-x-auto">
          <div className="flex gap-2 pb-2">
            {regions.map((region) => (
              <button
                key={region}
                onClick={() => {
                  setSelectedRegion(region);
                  setDisplayCount(12); // Reset display count on filter change
                }}
                className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all duration-300 ${
                  selectedRegion === region
                    ? 'bg-primary text-primary-foreground border-2 border-primary'
                    : 'bg-card border-2 border-border text-foreground hover:border-primary'
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-sm text-foreground/60">
            Mostrando {displayedCities.length} de {filteredCities.length} cidades
          </p>
        </div>

        {/* Cities Grid */}
        {displayedCities.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6 mb-8">
              {displayedCities.map((city) => (
                <CityCard
                  key={city.id}
                  city={city}
                  onClick={() => handleCityClick(city)}
                />
              ))}
            </div>

            {/* Load More Button */}
            {displayCount < filteredCities.length && (
              <div className="flex justify-center">
                <button
                  onClick={handleLoadMore}
                  className="px-8 py-3 md:py-4 bg-primary/20 border-2 border-primary text-primary rounded-lg font-bold hover:bg-primary/30 hover:shadow-lg hover:shadow-primary/50 transition-all duration-300"
                >
                  Carregar Mais ({filteredCities.length - displayCount} restantes)
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 md:py-24">
            <MapPin className="w-16 h-16 text-foreground/30 mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">Nenhuma cidade encontrada</h3>
            <p className="text-foreground/60 text-center max-w-md">
              Tente ajustar sua busca ou filtro para encontrar cidades
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
