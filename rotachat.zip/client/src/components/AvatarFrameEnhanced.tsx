import { useState } from 'react';
import { AvatarFrame as AvatarFrameType, rarityLabels, rarityColors } from '@/data/avatarFrames';

interface AvatarFrameEnhancedProps {
  src: string;
  alt: string;
  nickname: string;
  level?: number;
  status?: 'online' | 'offline' | 'busy';
  frame?: AvatarFrameType;
  size?: 'sm' | 'md' | 'lg';
  showParticles?: boolean;
}

/**
 * AvatarFrameEnhanced Component
 * 
 * Design Philosophy: Game-Inspired Avatar with Cyberpunk Neon
 * - Circular avatar with animated moldura
 * - Status indicator with pulse
 * - Level badge
 * - Particle effects
 * - Rarity-based colors
 * - Smooth animations
 */

export default function AvatarFrameEnhanced({
  src,
  alt,
  nickname,
  level = 1,
  status = 'online',
  frame,
  size = 'md',
  showParticles = true,
}: AvatarFrameEnhancedProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Size configurations
  const sizeConfig = {
    sm: { avatar: 'w-24 h-24', frame: 'p-1', status: 'w-5 h-5', level: 'text-xs' },
    md: { avatar: 'w-40 h-40', frame: 'p-2', status: 'w-7 h-7', level: 'text-sm' },
    lg: { avatar: 'w-56 h-56', frame: 'p-3', status: 'w-8 h-8', level: 'text-base' },
  };

  const config = sizeConfig[size];

  // Frame colors
  const frameColor = frame?.borderColor || 'oklch(0.65 0.25 260)';
  const glowColor = frame?.glowColor || 'rgba(0, 153, 255, 0.6)';
  const rarityLabel = frame ? rarityLabels[frame.rarity] : 'Sem Moldura';

  // Status colors
  const statusColors = {
    online: 'bg-green-400',
    offline: 'bg-gray-500',
    busy: 'bg-orange-500',
  };

  // Generate particles
  const particles = Array.from({ length: 6 }).map((_, i) => ({
    id: i,
    delay: i * 0.1,
    tx: (Math.random() - 0.5) * 100,
  }));

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Avatar Container */}
      <div
        className="relative"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Outer Frame (Moldura Externa) */}
        <div
          className={`${config.avatar} rounded-full ${config.frame} relative transition-all duration-300 ${
            isHovered ? 'scale-105' : 'scale-100'
          }`}
          style={{
            background: `linear-gradient(135deg, ${frameColor}, ${frameColor})`,
            boxShadow: `0 0 30px ${glowColor}, inset 0 0 20px rgba(0, 0, 0, 0.3)`,
            animation: isHovered ? 'frame-rotate 10s linear infinite' : 'frame-rotate 20s linear infinite',
          }}
        >
          {/* Inner Frame (Moldura Interna) */}
          <div
            className="w-full h-full rounded-full p-1 bg-background flex items-center justify-center"
            style={{
              boxShadow: `inset 0 0 10px rgba(0, 0, 0, 0.5)`,
            }}
          >
            {/* Avatar Image */}
            <img
              src={src}
              alt={alt}
              className={`${config.avatar} rounded-full object-cover animate-avatar-glow`}
              style={{
                boxShadow: `0 0 20px ${glowColor}`,
              }}
            />
          </div>
        </div>

        {/* Level Badge */}
        <div
          className={`absolute -top-2 -right-2 ${config.level} font-bold rounded-full bg-primary text-primary-foreground border-2 border-background flex items-center justify-center`}
          style={{
            width: size === 'sm' ? '24px' : size === 'md' ? '32px' : '40px',
            height: size === 'sm' ? '24px' : size === 'md' ? '32px' : '40px',
            boxShadow: `0 0 15px rgba(0, 153, 255, 0.6)`,
          }}
        >
          {level}
        </div>

        {/* Status Indicator */}
        <div
          className={`absolute -bottom-2 -right-2 ${config.status} rounded-full border-2 border-background ${statusColors[status]} animate-status-pulse`}
          style={{
            boxShadow: `0 0 10px ${statusColors[status] === 'bg-green-400' ? 'rgba(0, 255, 100, 0.6)' : statusColors[status] === 'bg-orange-500' ? 'rgba(255, 140, 0, 0.6)' : 'rgba(100, 100, 100, 0.6)'}`,
          }}
        />

        {/* Particles */}
        {showParticles && isHovered && (
          <div className="absolute inset-0 pointer-events-none">
            {particles.map((particle) => (
              <div
                key={particle.id}
                className="absolute w-1 h-1 rounded-full"
                style={{
                  left: '50%',
                  top: '50%',
                  background: glowColor,
                  animation: `particle-float 1s ease-out forwards`,
                  animationDelay: `${particle.delay}s`,
                  '--tx': `${particle.tx}px`,
                } as React.CSSProperties}
              />
            ))}
          </div>
        )}
      </div>

      {/* User Info */}
      <div className="text-center">
        <p className="font-bold text-foreground">{nickname}</p>
        <div className="flex items-center justify-center gap-2 mt-1">
          <span className="text-xs px-2 py-1 rounded-full" style={{ background: rarityColors[frame?.rarity || 'common'], color: '#fff' }}>
            {rarityLabel}
          </span>
          <span className="text-xs text-foreground/60">Nível {level}</span>
        </div>
      </div>
    </div>
  );
}


