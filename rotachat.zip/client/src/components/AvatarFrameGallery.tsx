import { useState } from 'react';
import { Lock, Check } from 'lucide-react';
import { avatarFrames, Rarity, rarityLabels, rarityColors } from '@/data/avatarFrames';

interface AvatarFrameGalleryProps {
  selectedFrameId?: string;
  onSelectFrame?: (frameId: string) => void;
}

/**
 * AvatarFrameGallery Component
 * 
 * Displays all available avatar frames organized by rarity
 * Shows locked/unlocked status
 * Allows selection of frame
 */

export default function AvatarFrameGallery({ selectedFrameId, onSelectFrame }: AvatarFrameGalleryProps) {
  const [expandedRarity, setExpandedRarity] = useState<Rarity | null>('common');

  const rarities: Rarity[] = ['common', 'rare', 'epic', 'legendary'];
  const framesByRarity = rarities.map((rarity) => ({
    rarity,
    frames: avatarFrames.filter((f) => f.rarity === rarity),
  }));

  return (
    <div className="w-full space-y-6">
      <div>
        <h3 className="text-xl font-bold text-foreground mb-2">Molduras de Avatar</h3>
        <p className="text-sm text-foreground/60">Selecione uma moldura para personalizar seu avatar</p>
      </div>

      {framesByRarity.map(({ rarity, frames }) => (
        <div key={rarity} className="space-y-3">
          {/* Rarity Header */}
          <button
            onClick={() => setExpandedRarity(expandedRarity === rarity ? null : rarity)}
            className="w-full flex items-center justify-between p-3 rounded-lg bg-card border-2 border-border hover:border-primary transition-colors duration-300"
          >
            <div className="flex items-center gap-3">
              <div
                className="w-3 h-3 rounded-full"
                style={{ background: rarityColors[rarity] }}
              />
              <span className="font-bold text-foreground capitalize">
                {rarityLabels[rarity]} ({frames.length})
              </span>
            </div>
            <span className="text-foreground/60">{expandedRarity === rarity ? '−' : '+'}</span>
          </button>

          {/* Frames Grid */}
          {expandedRarity === rarity && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pl-6">
              {frames.map((frame) => (
                <button
                  key={frame.id}
                  onClick={() => {
                    if (frame.isUnlocked && onSelectFrame) {
                      onSelectFrame(frame.id);
                    }
                  }}
                  disabled={!frame.isUnlocked}
                  className={`relative p-3 rounded-lg border-2 transition-all duration-300 ${
                    selectedFrameId === frame.id
                      ? 'border-primary bg-primary/20'
                      : frame.isUnlocked
                        ? 'border-border bg-card hover:border-primary'
                        : 'border-border/50 bg-card/50 opacity-60 cursor-not-allowed'
                  }`}
                  style={
                    frame.isUnlocked
                      ? {
                          boxShadow: selectedFrameId === frame.id ? `0 0 20px ${frame.glowColor}` : 'none',
                        }
                      : {}
                  }
                >
                  {/* Frame Preview */}
                  <div
                    className="w-full aspect-square rounded-lg mb-2 flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, ${frame.borderColor}, ${frame.borderColor})`,
                      boxShadow: frame.isUnlocked ? `0 0 15px ${frame.glowColor}` : 'none',
                      opacity: frame.isUnlocked ? 1 : 0.5,
                    }}
                  >
                    <div
                      className="w-full h-full rounded-lg p-1 bg-background flex items-center justify-center"
                      style={{
                        boxShadow: 'inset 0 0 10px rgba(0, 0, 0, 0.5)',
                      }}
                    >
                      <div
                        className="w-full h-full rounded-lg"
                        style={{
                          background: 'linear-gradient(135deg, rgba(100, 100, 150, 0.3), rgba(50, 50, 100, 0.3))',
                        }}
                      />
                    </div>
                  </div>

                  {/* Frame Name */}
                  <p className="text-xs font-bold text-foreground text-center truncate">{frame.name}</p>

                  {/* Status Icon */}
                  <div className="absolute top-1 right-1">
                    {frame.isUnlocked ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Lock className="w-4 h-4 text-foreground/40" />
                    )}
                  </div>

                  {/* Selected Indicator */}
                  {selectedFrameId === frame.id && (
                    <div
                      className="absolute inset-0 rounded-lg border-2"
                      style={{
                        borderColor: frame.borderColor,
                        boxShadow: `0 0 15px ${frame.glowColor}`,
                      }}
                    />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
