import { useState } from 'react';
import { Send, Smile, Paperclip, MoreVertical, Phone, Video } from 'lucide-react';
import AvatarWithFrame from './AvatarWithFrame';

interface User {
  id: string;
  nickname: string;
  avatar: string;
  isOnline: boolean;
  lastMessage?: string;
}

interface Message {
  id: string;
  userId: string;
  text: string;
  timestamp: string;
  isOwn: boolean;
}

/**
 * Chat Component
 * 
 * Design Philosophy: UOL Chat modernizado com Cyberpunk Neon
 * - Sidebar com lista de usuários
 * - Chat area com mensagens
 * - Avatares com moldura animada
 * - Input box com controles
 * - Totalmente responsivo
 */

export default function Chat() {
  const [selectedUserId, setSelectedUserId] = useState('user-1');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      userId: 'user-1',
      text: 'Oi! Tudo bem? 😊',
      timestamp: '14:32',
      isOwn: false,
    },
    {
      id: '2',
      userId: 'own',
      text: 'Tudo certo! E você?',
      timestamp: '14:33',
      isOwn: true,
    },
    {
      id: '3',
      userId: 'user-1',
      text: 'Tudo ótimo! Bora conversar?',
      timestamp: '14:34',
      isOwn: false,
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const users: User[] = [
    {
      id: 'user-1',
      nickname: 'Juh Prati',
      avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-1-7brhdWPrAqbGEgBpLCFGvh.webp',
      isOnline: true,
      lastMessage: 'Tudo ótimo! Bora conversar?',
    },
    {
      id: 'user-2',
      nickname: 'Anitas',
      avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-2-YU9bMDyqFhzg3PSwTWTEbM.webp',
      isOnline: true,
      lastMessage: 'Que legal! 🎉',
    },
    {
      id: 'user-3',
      nickname: 'Chat',
      avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-3-VAMTnvtuNfbHKtEWKJtd45.webp',
      isOnline: false,
      lastMessage: 'Até amanhã!',
    },
    {
      id: 'user-4',
      nickname: 'Conige',
      avatar: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-4-Z4xa5GtHZfA4JcQ2GVYRsK.webp',
      isOnline: true,
      lastMessage: 'Vamos jogar?',
    },
  ];

  const selectedUser = users.find((u) => u.id === selectedUserId);

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      const newMessage: Message = {
        id: String(messages.length + 1),
        userId: 'own',
        text: inputValue,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        isOwn: true,
      };
      setMessages([...messages, newMessage]);
      setInputValue('');
    }
  };

  return (
    <section className="w-full min-h-screen bg-background flex flex-col md:flex-row gap-0 md:gap-4 p-4 md:p-6 pt-24 md:pt-28">
      {/* Sidebar - User List */}
      <div className="w-full md:w-80 flex-shrink-0 mb-4 md:mb-0">
        <div className="glass rounded-lg p-4 border border-border">
          <h2 className="text-lg font-bold mb-4 text-foreground">Chat Público</h2>
          
          {/* User List */}
          <div className="space-y-2 max-h-96 md:max-h-screen overflow-y-auto">
            {users.map((user) => (
              <button
                key={user.id}
                onClick={() => setSelectedUserId(user.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                  selectedUserId === user.id
                    ? 'bg-primary/20 border border-primary'
                    : 'hover:bg-primary/10 border border-transparent'
                }`}
              >
                {/* Avatar */}
                <AvatarWithFrame
                  src={user.avatar}
                  alt={user.nickname}
                  nickname={user.nickname}
                  isOnline={user.isOnline}
                  size="md"
                />

                {/* User Info */}
                <div className="flex-1 text-left min-w-0">
                  <p className="font-medium text-foreground truncate">{user.nickname}</p>
                  <p className="text-xs text-foreground/60 truncate">{user.lastMessage}</p>
                </div>

                {/* Status Dot */}
                <div
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${
                    user.isOnline ? 'bg-green-400' : 'bg-gray-500'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-h-96 md:min-h-screen">
        {selectedUser && (
          <>
            {/* Chat Header */}
            <div className="glass rounded-lg p-4 border border-border mb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AvatarWithFrame
                  src={selectedUser.avatar}
                  alt={selectedUser.nickname}
                  nickname={selectedUser.nickname}
                  isOnline={selectedUser.isOnline}
                  size="lg"
                />
                <div>
                  <h3 className="font-bold text-foreground">{selectedUser.nickname}</h3>
                  <p className="text-sm text-foreground/60">
                    {selectedUser.isOnline ? '🟢 Online' : '🔴 Offline'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <button className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300">
                  <Phone className="w-5 h-5 text-primary" />
                </button>
                <button className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300">
                  <Video className="w-5 h-5 text-primary" />
                </button>
                <button className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300">
                  <MoreVertical className="w-5 h-5 text-foreground/60" />
                </button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 glass rounded-lg p-4 border border-border mb-4 overflow-y-auto space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg ${
                      message.isOwn
                        ? 'bg-primary/30 border border-primary/50 text-foreground'
                        : 'bg-card border border-border text-foreground'
                    }`}
                  >
                    <p className="text-sm md:text-base">{message.text}</p>
                    <p className="text-xs text-foreground/50 mt-1">{message.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Chat Input */}
            <div className="glass rounded-lg p-3 border border-border flex items-center gap-2">
              <button className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300">
                <Smile className="w-5 h-5 text-primary" />
              </button>
              <button className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300">
                <Paperclip className="w-5 h-5 text-primary" />
              </button>
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Digite uma mensagem..."
                className="flex-1 bg-transparent text-foreground placeholder-foreground/40 outline-none text-sm"
              />
              <button
                onClick={handleSendMessage}
                className="p-2 hover:bg-primary/20 rounded-lg transition-colors duration-300 text-primary"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
