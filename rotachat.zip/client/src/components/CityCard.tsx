import { Users, MapPin } from 'lucide-react';
import { City } from '@/data/cities';

interface CityCardProps {
  city: City;
  onClick?: () => void;
}

/**
 * CityCard Component
 * 
 * Design Philosophy: Cyberpunk Neon City Card
 * - Background image with overlay
 * - City name and state
 * - Online users count
 * - Neon border with glow
 * - Hover effects
 */

export default function CityCard({ city, onClick }: CityCardProps) {
  return (
    <button
      onClick={onClick}
      className="group relative w-full h-48 md:h-56 rounded-lg overflow-hidden transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-primary"
      style={{
        boxShadow: 'inset 0 0 20px rgba(0, 153, 255, 0.1)',
      }}
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${city.imageUrl})`,
        }}
      />

      {/* Overlay Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-80 group-hover:opacity-70 transition-opacity duration-300" />

      {/* Neon Border */}
      <div
        className="absolute inset-0 rounded-lg border-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          boxShadow: '0 0 20px rgba(0, 153, 255, 0.6), inset 0 0 20px rgba(0, 153, 255, 0.1)',
        }}
      />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-between p-4 md:p-6">
        
        {/* Top Section - Region Badge */}
        <div className="flex justify-between items-start">
          <div className="px-3 py-1 bg-primary/20 border border-primary/50 rounded-full backdrop-blur-sm">
            <span className="text-xs font-medium text-primary">{city.region}</span>
          </div>
        </div>

        {/* Bottom Section - City Info */}
        <div className="space-y-3">
          {/* City Name and State */}
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-white leading-tight">
              {city.name}
            </h3>
            <div className="flex items-center gap-1 mt-1">
              <MapPin className="w-4 h-4 text-secondary" />
              <p className="text-sm text-foreground/70">{city.state}</p>
            </div>
          </div>

          {/* Online Users */}
          <div className="flex items-center gap-2 pt-2 border-t border-foreground/20">
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span className="text-sm font-medium text-foreground/80">
              {city.onlineUsers.toLocaleString('pt-BR')} online
            </span>
          </div>
        </div>
      </div>

      {/* Hover Glow Effect */}
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg pointer-events-none"
        style={{
          boxShadow: '0 0 30px rgba(0, 153, 255, 0.3) inset',
        }}
      />
    </button>
  );
}
