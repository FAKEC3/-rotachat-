import { useState } from 'react';
import { Menu, X } from 'lucide-react';

/**
 * RotaChat Header Component
 * 
 * Design Philosophy: Cyberpunk Neon
 * - Glassmorphic background with blur effect
 * - Neon glow on logo and CTA button
 * - Smooth animations on hover (300ms)
 * - Fully responsive: hamburger menu on mobile
 * - Typography: Space Grotesk for logo, Inter for menu
 */

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { label: 'Home', href: 'https://www.rotachat.online' },
    { label: 'Salas', href: 'https://www.rotachat.online/salas' },
    { label: 'Chat Aleatório', href: 'https://www.rotachat.online/aleatorio' },
    { label: 'Cidades', href: 'https://www.rotachat.online/cidades' },
    { label: 'Jogos', href: 'https://www.rotachat.online/jogos' },
    { label: 'Sobre', href: 'https://www.rotachat.online/sobre' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 md:h-24">
          
          {/* Logo */}
          <a 
            href="https://www.rotachat.online" 
            className="flex items-center gap-2 group"
          >
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/rotachat-logo-bdTmZKYbHrg8sF5aqcFjTf.webp"
              alt="RotaChat Logo"
              className="h-12 md:h-14 w-auto transition-all duration-300 group-hover:animate-glow-pulse"
            />
          </a>

          {/* Desktop Navigation Menu */}
          <nav className="hidden md:flex items-center gap-8 flex-1 justify-center">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-sm font-medium text-foreground/80 hover:text-primary transition-all duration-300 relative group"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300"></span>
              </a>
            ))}
          </nav>

          {/* Desktop CTA Button */}
          <a
            href="https://www.rotachat.online/chat"
            className="hidden md:flex items-center justify-center px-6 py-2.5 rounded-lg font-semibold text-sm transition-all duration-300 bg-gradient-to-r from-accent via-orange-500 to-accent hover:shadow-lg hover:shadow-orange-500/50 hover:scale-105 text-accent-foreground glow-neon-orange"
          >
            Entrar no Chat
          </a>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-foreground hover:text-primary transition-colors duration-300"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <nav className="md:hidden pb-6 border-t border-border/50 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="flex flex-col gap-3 pt-4">
              {menuItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="px-4 py-2.5 text-sm font-medium text-foreground/80 hover:text-primary hover:bg-primary/10 rounded-lg transition-all duration-300"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <a
                href="https://www.rotachat.online/chat"
                className="mx-4 px-4 py-2.5 rounded-lg font-semibold text-sm text-center bg-gradient-to-r from-accent via-orange-500 to-accent hover:shadow-lg hover:shadow-orange-500/50 transition-all duration-300 text-accent-foreground glow-neon-orange"
                onClick={() => setIsMenuOpen(false)}
              >
                Entrar no Chat
              </a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
