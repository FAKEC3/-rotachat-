import { ArrowRight, Zap } from 'lucide-react';

/**
 * RotaChat Hero Component
 * 
 * Design Philosophy: Cyberpunk Neon
 * - Full-width hero with background image
 * - Neon glow overlay with gradient
 * - Impactful title and subtitle
 * - Two main CTAs: "Entrar no Chat" (primary), "Explorar Salas" (secondary)
 * - Floating particles effect
 * - Fully responsive
 */

export default function Hero() {
  return (
    <section className="relative w-full min-h-[90vh] md:min-h-screen overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/hero-background-aPydWUhPeS5ofq2JK8EmBk.webp)',
          backgroundAttachment: 'fixed',
        }}
      />

      {/* Neon Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-purple-900/40 to-pink-900/30 backdrop-blur-sm" />

      {/* Floating Particles Effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-primary/20 animate-pulse"
            style={{
              width: Math.random() * 100 + 20 + 'px',
              height: Math.random() * 100 + 20 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animation: `float ${Math.random() * 20 + 10}s ease-in-out infinite`,
              animationDelay: Math.random() * 5 + 's',
            }}
          />
        ))}
      </div>

      {/* Content Container */}
      <div className="relative z-10 h-full min-h-[90vh] md:min-h-screen flex items-center justify-center">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 py-12 md:py-20">
          <div className="max-w-3xl mx-auto text-center">
            
            {/* Main Title */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 md:mb-6 leading-tight">
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent animate-in fade-in slide-in-from-bottom-4 duration-700">
                Converse, Conheça, Divirta-se!
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl lg:text-2xl text-foreground/80 mb-8 md:mb-12 leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
              Entre agora e faça amigos de todo o Brasil! Salas de chat, jogos, música e muito mais em um só lugar.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center items-center animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
              
              {/* Primary CTA Button */}
              <a
                href="https://www.rotachat.online/chat"
                className="group relative px-8 md:px-10 py-3 md:py-4 rounded-lg font-bold text-base md:text-lg transition-all duration-300 flex items-center gap-2 bg-gradient-to-r from-accent via-orange-500 to-accent hover:shadow-2xl hover:shadow-orange-500/50 hover:scale-110 text-accent-foreground glow-neon-orange"
              >
                <Zap className="w-5 h-5 md:w-6 md:h-6" />
                <span>Entrar no Chat</span>
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 group-hover:translate-x-1 transition-transform" />
              </a>

              {/* Secondary CTA Button */}
              <a
                href="https://www.rotachat.online/cidades"
                className="group relative px-8 md:px-10 py-3 md:py-4 rounded-lg font-bold text-base md:text-lg transition-all duration-300 flex items-center gap-2 bg-primary/20 border-2 border-primary hover:bg-primary/30 hover:shadow-lg hover:shadow-primary/50 hover:scale-105 text-foreground"
              >
                <span>Explorar Salas</span>
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Trust Badge / Stats */}
            <div className="mt-12 md:mt-16 pt-8 md:pt-12 border-t border-primary/20 flex flex-col md:flex-row gap-6 md:gap-12 justify-center items-center text-center">
              <div className="animate-in fade-in duration-700 delay-300">
                <p className="text-2xl md:text-3xl font-bold text-primary">5.570+</p>
                <p className="text-sm md:text-base text-foreground/60">Cidades Brasileiras</p>
              </div>
              <div className="animate-in fade-in duration-700 delay-400">
                <p className="text-2xl md:text-3xl font-bold text-secondary">24/7</p>
                <p className="text-sm md:text-base text-foreground/60">Sempre Online</p>
              </div>
              <div className="animate-in fade-in duration-700 delay-500">
                <p className="text-2xl md:text-3xl font-bold text-accent">100%</p>
                <p className="text-sm md:text-base text-foreground/60">Gratuito</p>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="flex flex-col items-center gap-2">
          <p className="text-sm text-foreground/60">Scroll para explorar</p>
          <div className="w-6 h-10 border-2 border-primary/40 rounded-full flex justify-center p-2">
            <div className="w-1 h-2 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}
