import { useState } from 'react';
import AvatarFrameEnhanced from './AvatarFrameEnhanced';
import AvatarFrameGallery from './AvatarFrameGallery';
import { avatarFrames } from '@/data/avatarFrames';

/**
 * AvatarSystem Component
 * 
 * Complete avatar system with:
 * - Avatar display with moldura
 * - Frame gallery
 * - Customization options
 * - Preview in real-time
 */

export default function AvatarSystem() {
  const [selectedFrameId, setSelectedFrameId] = useState('frame-common-1');
  const [selectedAvatar, setSelectedAvatar] = useState(
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-1-7brhdWPrAqbGEgBpLCFGvh.webp'
  );
  const [nickname, setNickname] = useState('Nexus');
  const [level, setLevel] = useState(42);
  const [status, setStatus] = useState<'online' | 'offline' | 'busy'>('online');

  const avatarOptions = [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-1-7brhdWPrAqbGEgBpLCFGvh.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-2-YU9bMDyqFhzg3PSwTWTEbM.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-3-VAMTnvtuNfbHKtEWKJtd45.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-4-Z4xa5GtHZfA4JcQ2GVYRsK.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663407940071/CeaZWUcodmR9PA7QZmWeTo/avatar-5-7burmF2QisyK5p5wbxdtAZ.webp',
  ];

  const selectedFrame = avatarFrames.find((f) => f.id === selectedFrameId);

  const statusOptions: Array<'online' | 'offline' | 'busy'> = ['online', 'offline', 'busy'];
  const statusLabels = {
    online: 'Online',
    offline: 'Offline',
    busy: 'Ocupado',
  };

  return (
    <section className="w-full min-h-screen bg-background p-4 md:p-6 pt-24 md:pt-28">
      <div className="container mx-auto">
        
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">
            Sistema de Avatar
          </h1>
          <p className="text-foreground/60">
            Personalize seu avatar com molduras exclusivas e efeitos especiais
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column - Avatar Preview */}
          <div className="lg:col-span-1 flex flex-col items-center justify-start space-y-8">
            
            {/* Avatar Display */}
            <div className="w-full flex justify-center">
              <AvatarFrameEnhanced
                src={selectedAvatar}
                alt={nickname}
                nickname={nickname}
                level={level}
                status={status}
                frame={selectedFrame}
                size="lg"
                showParticles={true}
              />
            </div>

            {/* Quick Stats */}
            <div className="w-full glass rounded-lg p-6 space-y-4">
              <h3 className="font-bold text-foreground">Estatísticas</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-foreground/60">Experiência:</span>
                  <span className="text-foreground font-bold">1.250 / 2.000 XP</span>
                </div>
                <div className="w-full bg-card rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-secondary"
                    style={{ width: '62.5%' }}
                  />
                </div>
                <div className="flex justify-between pt-2">
                  <span className="text-foreground/60">Molduras:</span>
                  <span className="text-foreground font-bold">6 / 18 desbloqueadas</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Customization */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* User Info Section */}
            <div className="glass rounded-lg p-6 space-y-4">
              <h3 className="font-bold text-foreground mb-4">Informações do Perfil</h3>
              
              {/* Nickname */}
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">
                  Nickname
                </label>
                <input
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="w-full px-4 py-2 bg-card border-2 border-border rounded-lg text-foreground focus:outline-none focus:border-primary transition-colors"
                  maxLength={20}
                />
                <p className="text-xs text-foreground/50 mt-1">{nickname.length} / 20 caracteres</p>
              </div>

              {/* Level */}
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">
                  Nível
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={level}
                    onChange={(e) => setLevel(parseInt(e.target.value))}
                    className="flex-1"
                  />
                  <span className="text-foreground font-bold min-w-12">{level}</span>
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">
                  Status
                </label>
                <div className="flex gap-2">
                  {statusOptions.map((s) => (
                    <button
                      key={s}
                      onClick={() => setStatus(s)}
                      className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                        status === s
                          ? 'bg-primary text-primary-foreground border-2 border-primary'
                          : 'bg-card border-2 border-border text-foreground hover:border-primary'
                      }`}
                    >
                      {statusLabels[s]}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Avatar Selection */}
            <div className="glass rounded-lg p-6 space-y-4">
              <h3 className="font-bold text-foreground mb-4">Escolha seu Avatar</h3>
              <div className="grid grid-cols-5 gap-3">
                {avatarOptions.map((avatar, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedAvatar(avatar)}
                    className={`relative rounded-lg overflow-hidden border-2 transition-all duration-300 ${
                      selectedAvatar === avatar
                        ? 'border-primary'
                        : 'border-border hover:border-primary'
                    }`}
                    style={
                      selectedAvatar === avatar
                        ? {
                            boxShadow: '0 0 15px rgba(0, 153, 255, 0.6)',
                          }
                        : {}
                    }
                  >
                    <img
                      src={avatar}
                      alt={`Avatar ${index + 1}`}
                      className="w-full h-full object-cover aspect-square"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Frame Gallery */}
            <div className="glass rounded-lg p-6">
              <AvatarFrameGallery
                selectedFrameId={selectedFrameId}
                onSelectFrame={setSelectedFrameId}
              />
            </div>

            {/* Save Button */}
            <button className="w-full px-8 py-4 bg-primary/20 border-2 border-primary text-primary rounded-lg font-bold hover:bg-primary/30 hover:shadow-lg hover:shadow-primary/50 transition-all duration-300">
              💾 Salvar Personalização
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
