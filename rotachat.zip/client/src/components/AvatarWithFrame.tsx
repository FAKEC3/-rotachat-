import { Circle } from 'lucide-react';

interface AvatarWithFrameProps {
  src: string;
  alt: string;
  nickname: string;
  isOnline?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * AvatarWithFrame Component
 * 
 * Design Philosophy: Cyberpunk Neon with Whiteout Survival inspiration
 * - Animated neon glow effect
 * - Pulsing border animation
 * - Online/offline status indicator
 * - Responsive sizing
 */

export default function AvatarWithFrame({
  src,
  alt,
  nickname,
  isOnline = true,
  size = 'md',
  className = '',
}: AvatarWithFrameProps) {
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  };

  const statusSizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  };

  return (
    <div className={`relative inline-block ${className}`}>
      {/* Avatar Container with Animated Frame */}
      <div
        className={`${sizeClasses[size]} relative rounded-full overflow-hidden animate-glow-pulse`}
        style={{
          boxShadow: isOnline
            ? '0 0 20px rgba(0, 153, 255, 0.6), 0 0 40px rgba(157, 78, 221, 0.3), inset 0 0 20px rgba(0, 153, 255, 0.2)'
            : '0 0 15px rgba(100, 100, 100, 0.4), inset 0 0 10px rgba(100, 100, 100, 0.1)',
        }}
      >
        {/* Avatar Image */}
        <img
          src={src}
          alt={alt}
          className="w-full h-full object-cover"
        />

        {/* Animated Waves Overlay */}
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            border: isOnline ? '2px solid rgba(0, 153, 255, 0.4)' : '2px solid rgba(100, 100, 100, 0.2)',
            animation: isOnline ? 'wave 2s ease-in-out infinite' : 'none',
          }}
        />
      </div>

      {/* Online Status Indicator */}
      <div
        className={`absolute bottom-0 right-0 ${statusSizeClasses[size]} rounded-full border-2 border-background ${
          isOnline ? 'bg-green-400 glow-neon-blue' : 'bg-gray-500'
        }`}
        style={{
          boxShadow: isOnline ? '0 0 10px rgba(0, 255, 100, 0.8)' : 'none',
        }}
      />

      {/* Nickname Tooltip (optional) */}
      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap text-xs font-medium text-foreground/70 opacity-0 hover:opacity-100 transition-opacity duration-200 pointer-events-none">
        {nickname}
      </div>
    </div>
  );
}
