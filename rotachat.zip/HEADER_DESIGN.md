# Design Brainstorm: Header do RotaChat

## Contexto
O RotaChat é um portal de chat social brasileiro moderno, colorido e inspirado em plataformas como UOL Chat, Omegle e jogos online. O Header deve ser o primeiro contato visual do usuário com a marca, transmitindo energia, modernidade e confiabilidade.

---

## Três Abordagens de Design

### 🎨 Abordagem 1: Cyberpunk Neon (Selecionada)
**Design Movement:** Cyberpunk + Synthwave com influências de UI de jogos modernos

**Core Principles:**
- Contraste alto com cores neon vibrantes (gradientes azul → roxo → rosa)
- Profundidade visual através de sombras e blur effects
- Movimento sutil e dinâmico em hover states
- Tipografia ousada e moderna com peso visual

**Color Philosophy:**
- Paleta primária: Azul elétrico (#0099FF) → Roxo (#9D4EDD) → Rosa quente (#FF006E)
- Fundo: Escuro (quase preto com toque de azul profundo)
- Acentos: Laranja vibrante (#FF8C00) para CTAs
- Filosofia: Transmitir energia, juventude e dinamismo; cores quentes para ação, cores frias para estabilidade

**Layout Paradigm:**
- Header sticky no topo com glassmorphism (fundo semi-transparente com blur)
- Logo à esquerda com efeito glow sutil
- Menu horizontal centralizado com espaçamento generoso
- Botão CTA à direita em destaque com gradiente e sombra
- Responsivo: menu collapsa em hamburger no mobile com animação suave

**Signature Elements:**
1. **Glow Effect:** Logo e botão principal com halo luminoso que pulsa levemente
2. **Gradient Borders:** Linhas divisórias com gradientes neon
3. **Micro-interactions:** Hover states com efeito de "pop" e mudança de cor

**Interaction Philosophy:**
- Hover no menu: cor muda com transição suave, ícone aparece
- Hover no botão: gradiente se intensifica, sombra cresce
- Mobile: menu desliza de cima com backdrop blur
- Feedback visual imediato para todas as interações

**Animation:**
- Logo: glow pulse sutil (2s cycle) quando em hover
- Menu items: underline animado que cresce ao hover
- Botão: scale(1.05) com shadow intensificado
- Mobile menu: slide-in de cima com fade-in dos itens em cascata
- Transições: 300ms cubic-bezier(0.4, 0, 0.2, 1)

**Typography System:**
- Display: "Space Grotesk" (bold, 700) para logo e destaque
- Body: "Inter" (regular 400, medium 500) para menu
- CTA: "Space Grotesk" (600) para botão
- Hierarchy: Logo > Menu > Botão em peso visual

---

### 🎨 Abordagem 2: Minimalista Moderno
Foco em simplicidade, espaço branco generoso, cores pastel suaves, tipografia clean.

### 🎨 Abordagem 3: Retro Arcade
Inspirado em jogos 8-bit/16-bit com cores vibrantes, bordas quadradas, efeito de pixel art.

---

## Design Selecionado: Cyberpunk Neon ✨

**Por quê?** Alinha perfeitamente com a proposta do RotaChat: moderno, energético, social e inspirado em jogos. Transmite movimento e dinamismo mesmo em um Header estático.

---

## Especificações Técnicas

### Cores (OKLCH - Tailwind 4 compatible)
```
Primary Glow: oklch(0.65 0.25 260) // Azul elétrico
Secondary Glow: oklch(0.60 0.28 290) // Roxo
Accent Warm: oklch(0.65 0.30 30) // Laranja
Background Dark: oklch(0.08 0.01 260) // Quase preto com toque azul
Text Light: oklch(0.95 0.01 0) // Branco quase puro
```

### Tipografia
- Logo: Space Grotesk 700 (24-28px desktop, 20px mobile)
- Menu: Inter 500 (16px desktop, 14px mobile)
- Botão: Space Grotesk 600 (14-16px)

### Dimensões
- Height: 80px (desktop), 64px (mobile)
- Padding: 16px (mobile), 24px (desktop)
- Logo width: 180px (desktop), 140px (mobile)

### Efeitos
- Glassmorphism: backdrop-filter blur(12px), opacity 95%
- Glow: box-shadow com cor neon, blur 20px
- Transições: 300ms ease-in-out

---

## Componentes a Implementar
1. **Header Container** - Sticky, glassmorphic background
2. **Logo** - Com glow effect
3. **Navigation Menu** - Horizontal desktop, hamburger mobile
4. **CTA Button** - "Entrar no Chat" com gradiente
5. **Mobile Menu** - Overlay com backdrop blur
6. **Responsive Breakpoints** - Mobile (< 768px), Desktop (≥ 768px)

