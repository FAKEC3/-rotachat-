# Design Brainstorm: Sistema de Avatar do RotaChat

## Contexto
O Sistema de Avatar permite que usuários personalizem seus perfis com foto, moldura animada estilo jogo (Whiteout Survival), e efeitos visuais. A interface deve ser intuitiva, visualmente atraente e transmitir a emoção de um jogo moderno.

---

## Design Selecionado: Game-Inspired Avatar System com Cyberpunk Neon

**Design Movement:** Game UI (Whiteout Survival) + cyberpunk neon + glassmorphism

**Core Principles:**
- Avatar circular com moldura animada estilo jogo
- Múltiplas molduras desbloqueáveis (comum, rara, épica, lendária)
- Efeitos de glow e partículas animadas
- Status visual (online, offline, ocupado)
- Interface de customização intuitiva
- Animações suaves e responsivas

**Color Philosophy:**
- Moldura comum: Azul claro (neon)
- Moldura rara: Roxo (neon)
- Moldura épica: Ouro/Laranja (neon)
- Moldura lendária: Multicolor (gradiente neon)
- Glow: Cores correspondentes à moldura
- Fundo: Escuro com gradiente sutil

**Layout Paradigm:**
- Avatar circular centralizado
- Moldura com borda dupla (outer + inner)
- Ícone de status no canto inferior direito
- Informações do usuário abaixo (nickname, level, badges)
- Galeria de molduras disponíveis
- Customizador com preview em tempo real

**Signature Elements:**
1. **Avatar Frame**: Moldura dupla com glow pulsante
2. **Status Indicator**: Ícone com cor dinâmica (verde/cinza/laranja)
3. **Rarity Badge**: Indicador de raridade da moldura
4. **Particle Effects**: Partículas animadas ao redor do avatar
5. **Level Badge**: Nível do usuário em canto superior

**Interaction Philosophy:**
- Hover no avatar: intensifica glow e partículas
- Click na moldura: abre galeria de molduras
- Seleção de moldura: preview em tempo real
- Animação ao desbloquear: confete + som

**Animation:**
- Avatar glow: pulse 2s infinite
- Moldura: rotate 360° 20s infinite (lenta)
- Partículas: float up com fade out
- Status pulse: pulse 1s infinite
- Frame selection: scale(1.1) + glow intensificado

**Typography System:**
- Nickname: Space Grotesk 600, 16px
- Level: Inter 700, 12px
- Rarity: Inter 600, 11px
- Status: Inter 400, 10px

**Visual Assets Needed:**
- Reutilizar avatares já gerados (avatar-1 a avatar-5)
- Molduras em PNG com transparência
- Ícones de status
- Ícones de raridade

---

## Especificações Técnicas

### Avatar Dimensions
- Avatar size: 160px (desktop), 120px (mobile)
- Frame width: 8px
- Glow radius: 20px
- Status indicator: 32px

### Colors by Rarity
- Common: oklch(0.65 0.25 260) (azul)
- Rare: oklch(0.65 0.25 290) (roxo)
- Epic: oklch(0.65 0.30 30) (laranja)
- Legendary: gradient(azul → roxo → rosa → laranja)

### Efeitos
- Glassmorphism: backdrop-filter blur(8px)
- Avatar glow: box-shadow com cores neon
- Moldura glow: box-shadow com cores neon
- Partículas: CSS animations com @keyframes
- Transições: 300ms ease-in-out

### Animações
- Avatar glow: pulse 2s infinite
- Moldura rotate: rotate 360° 20s linear infinite
- Status pulse: pulse 1s infinite
- Partículas: float 3s ease-out forwards
- Frame selection: scale(1.1) + glow

---

## Componentes a Implementar
1. **AvatarFrame** - Avatar com moldura animada (aprimorado)
2. **AvatarFrameGallery** - Galeria de molduras disponíveis
3. **AvatarCustomizer** - Interface de customização
4. **AvatarProfile** - Perfil do usuário com avatar
5. **AvatarSystemPage** - Página dedicada com Header + Avatar System

---

## Dados de Molduras
- Comum (5): azul, verde, ciano, roxo claro, rosa
- Rara (5): roxo, magenta, ouro, prata, cyan
- Épica (5): ouro, laranja, vermelho, rosa quente, verde neon
- Lendária (3): multicolor, holográfico, cósmico

Total: 18 molduras desbloqueáveis

---

## Estrutura de Dados
```typescript
interface AvatarFrame {
  id: string;
  name: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  color: string;
  glowColor: string;
  isUnlocked: boolean;
  unlockedAt?: Date;
}

interface UserAvatar {
  userId: string;
  currentFrame: string;
  avatarUrl: string;
  nickname: string;
  level: number;
  status: 'online' | 'offline' | 'busy';
  badges: string[];
}
```

