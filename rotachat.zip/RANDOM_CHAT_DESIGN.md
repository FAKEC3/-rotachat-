# Design Brainstorm: Chat Aleatório do RotaChat

## Contexto
O Chat Aleatório conecta dois usuários aleatoriamente para uma conversa anônima, inspirado no Omegle. A interface deve ser simples, intuitiva e transmitir a emoção de conhecer alguém novo.

---

## Design Selecionado: Omegle Modernizado com Cyberpunk Neon

**Design Movement:** Omegle clássico + cyberpunk neon + glassmorphism

**Core Principles:**
- Interface centrada com dois avatares lado a lado (VS)
- Área de chat no centro com destaque
- Botões de ação bem definidos (Próximo, Desconectar, Reportar)
- Sensação de "encontro" com animações dinâmicas
- Glassmorphic cards com neon borders

**Color Philosophy:**
- Fundo: Escuro com gradiente sutil
- Cards: Glassmorphic com borda neon
- Avatares: Moldura com glow neon (esquerda e direita)
- Botões: Próximo (azul), Desconectar (vermelho), Reportar (laranja)
- Filosofia: Transmitir emoção, encontro, conexão

**Layout Paradigm:**
- Full-width hero section com dois avatares lado a lado
- "VS" no centro como divisor
- Informações do usuário (nickname, status) abaixo de cada avatar
- Chat area centralizada abaixo
- Botões de ação em linha horizontal
- Mobile: Stack vertical com avatares em cima, chat no meio, botões embaixo

**Signature Elements:**
1. **VS Divider**: Elemento central com "VS" e animação de pulse
2. **Avatar Pair**: Dois avatares com moldura neon lado a lado
3. **Connection Indicator**: Linha conectando os avatares com glow
4. **Action Buttons**: Botões com ícones e cores distintas

**Interaction Philosophy:**
- Hover nos avatares: intensifica o glow
- Click em "Próximo": animação de transição (fade out + fade in)
- Click em "Desconectar": confirmação visual
- Hover nos botões: scale(1.05) + glow intensificado

**Animation:**
- Avatar glow: pulse 2s infinite
- VS divider: pulse 1.5s infinite
- Conexão: linha animada com movimento
- Transição de usuário: fade out (300ms) + fade in (300ms)
- Botões: hover scale + glow

**Typography System:**
- Nickname: Space Grotesk 600, 16px
- Status: Inter 400, 12px
- Mensagem: Inter 400, 14px
- Botões: Space Grotesk 600, 14px

**Visual Assets Needed:**
- Reutilizar avatares já gerados (avatar-1 a avatar-5)
- Ícones de ação (próximo, desconectar, reportar)

---

## Especificações Técnicas

### Layout
- Avatar size: 120px (desktop), 80px (mobile)
- Chat area: max-width 600px, height 400px
- Button size: 48px (icon) + padding
- Spacing: 40px entre avatares e chat

### Cores
- Avatar border: oklch(0.65 0.25 260) (azul)
- VS divider: oklch(0.65 0.30 330) (rosa)
- Button Next: oklch(0.65 0.25 260) (azul)
- Button Disconnect: oklch(0.65 0.25 10) (vermelho)
- Button Report: oklch(0.65 0.30 30) (laranja)

### Efeitos
- Glassmorphism: backdrop-filter blur(12px)
- Avatar glow: box-shadow com cores neon
- Connection line: gradient com animação
- Transições: 300ms ease-in-out

---

## Componentes a Implementar
1. **RandomChatContainer** - Layout principal
2. **AvatarPair** - Dois avatares com VS divider
3. **ChatWindow** - Área de mensagens
4. **ActionButtons** - Botões de ação (Próximo, Desconectar, Reportar)
5. **ConnectionLine** - Linha animada conectando avatares
6. **RandomChatPage** - Página dedicada com Header + RandomChat

