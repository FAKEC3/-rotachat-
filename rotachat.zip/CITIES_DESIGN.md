# Design Brainstorm: Salas por Cidade do RotaChat

## Contexto
A seção Salas por Cidade permite que usuários encontrem salas de chat específicas de cada cidade brasileira. Com 5.570 cidades para acomodar, a interface deve ser intuitiva, performática e visualmente atraente.

---

## Design Selecionado: City Hub com Cyberpunk Neon

**Design Movement:** City discovery interface + cyberpunk neon + glassmorphism

**Core Principles:**
- Busca em tempo real com autocomplete
- Filtros por região/estado
- Grid responsivo de cidades com imagens de fundo
- Lazy loading para performance
- Informações de usuários online por cidade
- Glassmorphic cards com neon borders

**Color Philosophy:**
- Fundo: Escuro com gradiente sutil
- Cards: Glassmorphic com borda neon
- Imagens de fundo: Cidades com skylines vibrantes
- Overlay: Gradiente semi-transparente para legibilidade
- Cores neon para destaque e interação

**Layout Paradigm:**
- Header com busca e filtros
- Grid responsivo de cidades (2 colunas mobile, 3-4 desktop)
- Cada card exibe: imagem de fundo, nome da cidade, estado, usuários online
- Hover: intensifica glow, mostra mais informações
- Mobile: Stack vertical com busca em destaque

**Signature Elements:**
1. **Search Bar**: Input com ícone de busca, autocomplete
2. **City Cards**: Imagem de fundo + overlay + informações
3. **Region Filter**: Abas ou dropdown para filtrar por região
4. **Online Counter**: Número de usuários online por cidade
5. **Neon Border**: Borda com glow nos cards

**Interaction Philosophy:**
- Busca: filtra cidades em tempo real
- Filtro: muda visualização por região
- Hover no card: intensifica glow, mostra overlay com mais info
- Click no card: abre sala da cidade

**Animation:**
- Search: fade-in suave
- Cards: fade-in em cascata com stagger
- Hover: scale(1.05) + glow intensificado
- Lazy load: fade-in ao entrar em viewport

**Typography System:**
- Título: Space Grotesk 700, 24px
- Nome da cidade: Space Grotesk 600, 18px
- Estado: Inter 400, 12px
- Online count: Inter 600, 14px

**Visual Assets Needed:**
- Imagens de background para cidades principais (São Paulo, Rio de Janeiro, Belo Horizonte, Salvador, Brasília)
- Ícone de busca
- Ícone de localização

---

## Especificações Técnicas

### Layout
- Search bar: full-width, height 48px
- Filter tabs: horizontal scroll no mobile
- Grid: 2 cols mobile, 3 cols tablet, 4 cols desktop
- Card size: 280px x 200px (desktop), 100% x 150px (mobile)
- Gap: 16px entre cards

### Cores
- Search background: oklch(0.15 0.02 260)
- Card border: oklch(0.65 0.25 260) (azul)
- Online count: oklch(0.65 0.25 140) (verde)
- State text: oklch(0.40 0.05 0) (cinza)

### Efeitos
- Glassmorphism: backdrop-filter blur(12px)
- Card glow: box-shadow com cores neon
- Overlay: gradient rgba(0, 0, 0, 0.4) to rgba(0, 0, 0, 0.8)
- Transições: 300ms ease-in-out

### Performance
- Lazy loading: Intersection Observer
- Virtualization: renderizar apenas cards visíveis
- Debounce search: 300ms
- Memoização de componentes

---

## Componentes a Implementar
1. **CitiesContainer** - Layout principal
2. **SearchBar** - Input com autocomplete
3. **RegionFilter** - Abas/dropdown de regiões
4. **CityCard** - Card individual com imagem e info
5. **CityGrid** - Grid com lazy loading
6. **CitiesPage** - Página dedicada com Header + Cities

---

## Dados de Cidades
- Total: 5.570 cidades brasileiras
- Estrutura: { id, name, state, region, population, online_users, image_url }
- Regiões: Norte, Nordeste, Centro-Oeste, Sudeste, Sul
- Estados: 27 (26 estados + DF)

---

## Estratégia de Performance
1. **Lazy Loading**: Carregar cidades conforme scroll
2. **Virtualization**: Renderizar apenas cards visíveis
3. **Memoização**: React.memo para CityCard
4. **Debounce**: Busca com delay de 300ms
5. **Image Optimization**: WebP com fallback PNG
6. **Caching**: Armazenar dados em localStorage

